// Initialize Firebase
const firebaseConfig = {
    apiKey: "AIzaSyBloghfhFwhEc4r9qdOTel7CnJ6iz7m9k0",
    authDomain: "smart-bin-b30d2.firebaseapp.com",
    databaseURL: "https://smart-bin-b30d2-default-rtdb.firebaseio.com",
    projectId: "smart-bin-b30d2",
    storageBucket: "smart-bin-b30d2.appspot.com",
    messagingSenderId: "23174065932",
    appId: "1:23174065932:web:2c546fe56c7d9bcc412329",
    measurementId: "G-ED76D79XWV"
};
// firebase.initializeApp(firebaseConfig);

// const auth = firebase.auth();

// function handleLogin() {
//     const username = document.getElementById('user-username').value;
//     const password = document.getElementById('user-password').value;

//     auth.signInWithEmailAndPassword(username, password)
//         .then((userCredential) => {
//             // Login successful
//             const user = userCredential.user;
//             window.location.href = 'adminportal.html'; // Redirect to admin portal
//         })
//         .catch((error) => {
//             // Handle Errors here.
//             const errorCode = error.code;
//             const errorMessage = error.message;
//             alert(`Error: ${errorMessage}`);
//         });
// }







firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();

function handleSignUp() {
    const name = document.getElementById('admin-name').value;
    const email = document.getElementById('admin-username').value;
    const password = document.getElementById('admin-password').value;

    auth.createUserWithEmailAndPassword(email, password)
        .then((userCredential) => {
            // Sign-up successful
            const user = userCredential.user;
            alert('Sign-up successful!');

            // Optionally, update the user's profile with the name
            return user.updateProfile({
                displayName: name
            });
        })
        .then(() => {
            // Redirect to login or another page
            window.location.href = 'admin-login.html'; // Redirect to admin login page or another page
        })
        .catch((error) => {
            // Handle Errors here.
            const errorCode = error.code;
            const errorMessage = error.message;
            alert(`Error: ${errorMessage}`);
        });
}






// Login function
function handleLogin() {
    const email = document.getElementById('user-username').value;
    const password = document.getElementById('user-password').value;

    // Firebase Authentication: Sign in with email and password
    auth.signInWithEmailAndPassword(email, password)
        .then((userCredential) => {
            // Successfully logged in
            console.log("User logged in:", userCredential.user);
            alert("Login successful!");
            // Redirect to dashboard or another page
            window.location.href = "index.html"; // Change to your desired page
        })
        .catch((error) => {
            // Error handling
            console.error("Error during login:", error.message);
            alert("Login failed: " + error.message);
        });
}

// Check if a user is already logged in
auth.onAuthStateChanged((user) => {
    if (user) {
        // User is logged in, redirect to the dashboard
        window.location.href = "index.html"; // Change to your dashboard page
    }
});




